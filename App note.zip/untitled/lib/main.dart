import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Add note',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: const MyHomePage(title: 'Add note'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Map<String, dynamic>> _tasks = [];
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _editTaskController = TextEditingController();
  int _editIndex = -1;

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  //using shared preferences DB

  void _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _tasks = (prefs.getStringList('tasks') ?? []).map((task) {
        return {
          'description': task,
          'completed': false,

        };
      }).toList();
    });
  }

  void _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasksDescription = _tasks.map((task) => task['description'] as String).toList();
    //print('Tasks before saving: $tasksDescription');
    await prefs.setStringList('tasks', tasksDescription);
    //print('Tasks after saving: $tasksDescription');
  }


  void _addTask() {
    setState(() {
      _tasks.add(<String, Object>{
        'description': _taskController.text,
        'completed': false,
      });

      _taskController.clear();
      _saveTasks();
    });
  }

  /*void _removeTask(int index) {
    setState(() {
      _tasks.removeAt(index);
      _saveTasks();
    });
  }*/

  /*void _editTask(int index) {
    setState(() {
      _editIndex = index;
      _editTaskController.text = _tasks[index]['description'];
    });
  }*/

  void _removeTask(int index) {
    _editIndex = index;
    _editTaskController.text = _tasks[index]['description'];
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Delete ...'),

          actions: <Widget>[
            TextButton(
              onPressed: () {
                setState(() {
                  _tasks.removeAt(index);
                  _saveTasks();
                  Navigator.of(context).pop();
                });
              },
              child: Text('Delete'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _editIndex = -1;
                  Navigator.of(context).pop();
                });
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _editTask(int index) {
    _editIndex = index;
    _editTaskController.text = _tasks[index]['description'];
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit '),
          content: TextField(
            controller: _editTaskController,
            decoration: InputDecoration(hintText: 'Enter task...'),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                setState(() {
                  _tasks[_editIndex]['description'] = _editTaskController.text;
                  _editIndex = -1;
                  Navigator.of(context).pop();
                });
              },
              child: Text('Save'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _editIndex = -1;
                  Navigator.of(context).pop();
                });
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _saveEditedTask(int index) {
    setState(() {
      _tasks[index]['description'] = _editTaskController.text;
      _editIndex = -1;
      _saveTasks();
    });
  }

  void _toggleTaskCompletion(int index) {
    setState(() {
    //  print(_tasks[index]['completed']);
      _tasks[index]['completed'] = !_tasks[index]['completed'];
      //print("---------------------------");
     // print(_tasks[index]['completed']);
      _saveTasks();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              itemCount: _tasks.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    _tasks[index]['description'],
                    style: TextStyle(
                      decoration: _tasks[index]['completed']
                          ? TextDecoration.lineThrough
                          : TextDecoration.none,
                    ),
                  ),
                  leading: Checkbox(
                    value: _tasks[index]['completed'],
                    onChanged: (bool? value) {
                      _toggleTaskCompletion(index);
                    },
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () {
                          _editTask(index);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          _removeTask(index);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _taskController,
                    decoration: InputDecoration(
                      hintText: 'Enter task...',
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: _addTask,
                  child: Text('Add'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
